#include <iostream>
#include <nvml.h>

int main()
{
    nvmlReturn_t result;

    result = nvmlInit_v2();
    if(result != NVML_SUCCESS)
    {
        std::cout << "Failed to initialize NVML: " << nvmlErrorString(result) << std::endl;
        return 1;
    }

    // get the number of devices
    unsigned int nvml_devices;
    result = nvmlDeviceGetCount(&nvml_devices);
    std::cout << "found " << nvml_devices << " devices" << std::endl;

    //get device name
    for(unsigned int i = 0; i < nvml_devices; i++)
    {
        nvmlDevice_t device;
        result = nvmlDeviceGetHandleByIndex(i, &device);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device handle: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        char name[NVML_DEVICE_NAME_BUFFER_SIZE];
        result = nvmlDeviceGetName(device, name, NVML_DEVICE_NAME_BUFFER_SIZE);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device name: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        std::cout << "Device " << i << " name: " << name << std::endl;
    }
    //get device temperature
    for(unsigned int i = 0; i < nvml_devices; i++)
    {
        nvmlDevice_t device;
        result = nvmlDeviceGetHandleByIndex(i, &device);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device handle: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        unsigned int temperature;
        result = nvmlDeviceGetTemperature(device, NVML_TEMPERATURE_GPU, &temperature);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device temperature: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        std::cout << "Device " << i << " temperature: " << temperature << std::endl;
    }

    // get device power usage
    for(unsigned int i = 0; i < nvml_devices; i++)
    {
        nvmlDevice_t device;
        result = nvmlDeviceGetHandleByIndex(i, &device);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device handle: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        unsigned int power;
        result = nvmlDeviceGetPowerUsage(device, &power);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device power usage: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        std::cout << "Device " << i << " power usage: " << power <<"[mW]" << std::endl;
    }

    // get device power limit
    for(unsigned int i = 0; i < nvml_devices; i++)
    {
        nvmlDevice_t device;
        result = nvmlDeviceGetHandleByIndex(i, &device);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device handle: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        unsigned int power;
        result = nvmlDeviceGetPowerManagementLimit(device, &power);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device power limit: " << nvmlErrorString(result) << std::endl;
            //return 1;
        }

        std::cout << "Device " << i << " power limit: " << power <<"[mW]" << std::endl;
    }

    // get device clock
    for(unsigned int i = 0; i < nvml_devices; i++)
    {
        nvmlDevice_t device;
        result = nvmlDeviceGetHandleByIndex(i, &device);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device handle: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        unsigned int clock;
        result = nvmlDeviceGetClockInfo(device, NVML_CLOCK_GRAPHICS, &clock);
        if(result != NVML_SUCCESS)
        {
            std::cout << "Failed to get device clock: " << nvmlErrorString(result) << std::endl;
            return 1;
        }

        std::cout << "Device " << i << " clock: " << clock <<"[MHz]" << std::endl;
    }
    result = nvmlShutdown();

    if(result != NVML_SUCCESS)
    {
        std::cout << "Failed to initialize NVML: " << nvmlErrorString(result) << std::endl;
        return 1;
    }

}
